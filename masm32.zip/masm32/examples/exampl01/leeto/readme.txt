X-Calibre's 31337 program.
~~~~~~~~~~~~~~~~~~~~~~~~~

This program definitely deserves an explanation. For those who have never
experienced / suffered the IRC medium, there is a phenomenon where some
under the age of 12 consider it to be elite to be able to run scripts in
their IRC program that modifies text so that it is "readable" but
unintelligible to most. 

This program was in part, X-Calibre's answer to the mIRC scripts but it
also demonstrates a very flexible approach to using masm macros and equates.

To use it, type some text into the top text box and press the left side
button at the bottom if you cannot understand it. It will convert the text
you typed into "readable"( ? ) IRC kiddy text.

You can exit the program by pressing the lower right button and then the
left side button in the dialog box.

A toy for your pleasure by X-Calibre
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~